"use strict";
const headerOfSections = Array.from(
  document.querySelectorAll("section header")
);
headerOfSections.forEach(function(headers) {
  headers.onclick = function(e) {
    const oldActiveDisplay = document.querySelector("section div.active");
    oldActiveDisplay.classList.remove("active");
    const nowActiveDisplay = this.nextElementSibling;
    nowActiveDisplay.classList.add("active");
  };
});
